/* Formatted on 25/4/2024 11:18:33 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- SQL Monitoring

/*
    STATISTICS_LEVEL : ALL or TYPICAL (the default value)
    CONTROL_MANAGEMENT_PACK_ACCESS : DIAGNOSTIC+TUNING (the default value) 
    ** SQL monitoring is a feature of the Oracle Database Tuning Pack
    SQL monitoring is automatically started when a SQL statement runs parallel, 
      or when it has consumed at least five seconds of the CPU or I/O time in 
      a single execution.
    After the execution ends, monitoring information is not deleted immediately, 
      but is kept in the V$SQL_MONITOR view for at least one minute. The entry 
      is eventually deleted so its space can be reclaimed as new statements are monitored.
    The V$SQL_MONITOR and V$SQL_PLAN_MONITOR views can be used in conjunction with 
      the following views to get additional information about the execution that is monitored:
      V$SQL, V$SQL_PLAN, V$ACTIVE_SESSION_HISTORY, V$SESSION_LONGOPS, and V$SESSION
*/

-- Otra sesion

SELECT COUNT (*) FROM cc.aud_cuenta_efectivo;

SET LONG 10000000
SET LONGCHUNKSIZE 10000000
SET LINESIZE 200

SELECT DBMS_SQLTUNE.report_sql_monitor
  FROM DUAL;
  
/*  
    The report then displays the execution path currently used by your statement. 
    SQL monitoring gives you the display of the current operation that executes in the plan. 
    This enables you to detect parts of the plan that are the most time consuming, so that 
    you can focus your analysis on those parts. 
    The running operation is marked by an arrow in the Id column of the report.
    
    The Time Active(s) column shows how long the operation has been active 
      (the delta in seconds between the first and the last active time).
    The Start Active column shows, in seconds, when the operation in the execution plan 
      started relative to the SQL statement execution start time. 
    In this report, at (+1s Start Active) was the first to start  and ran for the first XX seconds so far.
    The Starts column shows the number of times the operation in the execution plan was executed.
    The Rows (Actual) column indicates the number of rows produced, and the Rows (Estim) column shows 
       the estimated cardinality from the optimizer.
    The Activity (percent) and Activity Detail (sample #) columns are derived by joining the V$SQL_PLAN_MONITOR 
      and V$ACTIVE_SESSION_HISTORY views. 
    Activity (percent) shows the percentage of database time consumed by each operation of the execution plan. 
    Activity Detail (sample#) shows the nature of that activity (such as CPU or wait event).
    Progress, shows progress monitoring information for the operation from the V$SESSION_LONGOPS view. 
    The Memory and Temp columns indicate the amount of memory and temporary space consumed by corresponding 
      operation of the execution plan.
*/  