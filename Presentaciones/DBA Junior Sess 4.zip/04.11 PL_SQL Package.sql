/* Formatted on 26/4/2024 17:46:27 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/
-- https://www.oracletutorial.com/plsql-tutorial/plsql-package/

/*******************************************************************************
  PL/SQL Package
*******************************************************************************/

-- https://www.oracletutorial.com/plsql-tutorial/plsql-package-specification/

/*******************************************************************************
  PL/SQL Package Specification
*******************************************************************************/

/*
CREATE [OR REPLACE] PACKAGE [schema_name.]<package_name> IS | AS
    declarations;
END [<package_name>];
*/

CREATE OR REPLACE PACKAGE sample
AS
    gc_shipped    CONSTANT VARCHAR (10) := 'Shipped';
    gc_pending    CONSTANT VARCHAR (10) := 'Pending';
    gc_canceled   CONSTANT VARCHAR (10) := 'Canceled';
    gv_status              VARCHAR (10);
END sample;

BEGIN
    sample.gv_status;
    DBMS_OUTPUT.PUT_LINE (sample.gv_status);
END;

BEGIN
    DBMS_OUTPUT.PUT_LINE (sample.gv_status);
END;

CREATE OR REPLACE PACKAGE order_mgmt
AS
    gc_shipped_status    CONSTANT VARCHAR (10) := 'Shipped';
    gc_pending_status    CONSTANT VARCHAR (10) := 'Pending';
    gc_canceled_status   CONSTANT VARCHAR (10) := 'Canceled';

    -- cursor that returns the order detail
    CURSOR g_cur_order (p_order_id NUMBER)
    IS
        SELECT customer_id,
               status,
               salesman_id,
               order_date,
               item_id,
               product_name,
               quantity,
               unit_price
          FROM order_items
               INNER JOIN orders USING (order_id)
               INNER JOIN products USING (product_id)
         WHERE order_id = p_order_id;

    -- get net value of a order
    FUNCTION get_net_value (p_order_id NUMBER)
        RETURN NUMBER;

    -- Get net value by customer
    FUNCTION get_net_value_by_customer (p_customer_id NUMBER, p_year NUMBER)
        RETURN NUMBER;
END order_mgmt;


-- https://www.oracletutorial.com/plsql-tutorial/plsql-package-body/
/*******************************************************************************
  PL/SQL Package Body
*******************************************************************************/
/*
CREATE [OR REPLACE] PACKAGE BODY [schema_name.]<package_name> IS | AS
    declarations
    implementations;
[BEGIN
EXCEPTION]
END [<package_name>];
*/


CREATE OR REPLACE PACKAGE BODY order_mgmt
AS
    -- get net value of a order
    FUNCTION get_net_value (p_order_id NUMBER)
        RETURN NUMBER
    IS
        ln_net_value   NUMBER;
    BEGIN
        SELECT SUM (unit_price * quantity)
          INTO ln_net_value
          FROM order_items
         WHERE order_id = p_order_id;

        RETURN p_order_id;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            DBMS_OUTPUT.PUT_LINE (SQLERRM);
    END get_net_value;

    -- Get net value by customer
    FUNCTION get_net_value_by_customer (p_customer_id NUMBER, p_year NUMBER)
        RETURN NUMBER
    IS
        ln_net_value   NUMBER;
    BEGIN
        SELECT SUM (quantity * unit_price)
          INTO ln_net_value
          FROM order_items INNER JOIN orders USING (order_id)
         WHERE     EXTRACT (YEAR FROM order_date) = p_year
               AND customer_id = p_customer_id
               AND status = gc_shipped_status;

        RETURN ln_net_value;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            DBMS_OUTPUT.PUT_LINE (SQLERRM);
    END get_net_value_by_customer;
END order_mgmt;


SELECT order_mgmt.get_net_value_by_customer (1, 2017) sales FROM DUAL;