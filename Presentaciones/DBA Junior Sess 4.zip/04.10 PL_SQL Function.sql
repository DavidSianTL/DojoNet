/* Formatted on 26/4/2024 17:36:35 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/
-- https://www.oracletutorial.com/plsql-tutorial/plsql-function/

/*******************************************************************************
  PL/SQL Function
*******************************************************************************/

/*
CREATE [OR REPLACE] FUNCTION function_name (parameter_list)
    RETURN return_type
IS
    [declarative section]
BEGIN
    [executable section]
[EXCEPTION]
    [exception-handling section]
END;
*/

CREATE OR REPLACE FUNCTION get_total_sales (in_year PLS_INTEGER)
    RETURN NUMBER
IS
    l_total_sales   NUMBER := 0;
BEGIN
      -- get total sales
      SELECT SUM (unit_price * quantity)
        INTO l_total_sales
        FROM order_items INNER JOIN orders USING (order_id)
       WHERE status = 'Shipped'
    GROUP BY EXTRACT (YEAR FROM order_date)
      HAVING EXTRACT (YEAR FROM order_date) = in_year;

    -- return the total sales
    RETURN l_total_sales;
END;

-- in an assignment statement:

DECLARE
    l_sales_2017   NUMBER := 0;
BEGIN
    l_sales_2017 := get_total_sales (2017);
    DBMS_OUTPUT.PUT_LINE ('Sales 2017: ' || l_sales_2017);
END;

-- in a Boolean expression

BEGIN
    IF get_total_sales (2017) > 10000000
    THEN
        DBMS_OUTPUT.PUT_LINE ('Sales 2017 is above target');
    END IF;
END;

-- in an SQL statement

SELECT get_total_sales (2017) FROM DUAL;


-- DROP FUNCTION function_name;

DROP FUNCTION get_total_sales;