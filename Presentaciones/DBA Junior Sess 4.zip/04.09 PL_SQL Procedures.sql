/* Formatted on 26/4/2024 17:32:23 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/
-- https://www.oracletutorial.com/plsql-tutorial/plsql-procedure/

/*******************************************************************************
  PL/SQL Procedure
*******************************************************************************/

/*

CREATE [OR REPLACE ] PROCEDURE procedure_name (parameter_list)     
IS
    [declaration statements]
BEGIN
  [execution statements]
EXCEPTION
  [exception handler]
END [procedure_name ];

*/

CREATE OR REPLACE PROCEDURE print_contact (in_customer_id NUMBER)
IS
    r_contact   contacts%ROWTYPE;
BEGIN
    -- get contact based on customer id
    SELECT *
      INTO r_contact
      FROM contacts
     WHERE customer_id = p_customer_id;

    -- print out contact's information
    DBMS_OUTPUT.put_line (
           r_contact.first_name
        || ' '
        || r_contact.last_name
        || '<'
        || r_contact.email
        || '>');
EXCEPTION
    WHEN OTHERS
    THEN
        DBMS_OUTPUT.put_line (SQLERRM);
END;

-- EXECUTE procedure_name( arguments);

EXEC print_contact(100);

-- DROP PROCEDURE procedure_name; 

DROP PROCEDURE print_contact;