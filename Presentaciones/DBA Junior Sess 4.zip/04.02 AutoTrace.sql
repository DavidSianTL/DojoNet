/* Formatted on 24/4/2024 14:48:17 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- AutoTrace: Database administrator (DBA) privileges are required to grant the PLUSTRACE role

/*
   SET AUTOTRACE ON: The AUTOTRACE report includes both the optimizer execution 
                     plan and the SQL statement execution statistics.
   SET AUTOTRACE TRACEONLY EXPLAIN: The AUTOTRACE report shows only the optimizer 
                                    execution path without executing the statement.
   SET AUTOTRACE ON STATISTICS: The AUTOTRACE report shows the SQL statement 
                                execution statistics and rows.
   SET AUTOTRACE TRACEONLY: This is similar to SET AUTOTRACE ON, but it 
                            suppresses the printing of the user�s query output, 
                            if any. If STATISTICS is enabled, the query data is 
                            still fetched, but not printed.
   SET AUTOTRACE OFF: No AUTOTRACE report is generated. This is the default.
*/

SHOW AUTOTRACE
SET AUTOTRACE TRACEONLY STATISTICS

SELECT * FROM products;

/*
AUTOTRACE: Statistics
  The statistics are recorded by the server when your statement executes and indicate the system resources required to execute your statement. The results include the following statistics: 
      recursive calls: is the number of recursive calls generated at both the user and system level. Oracle Database maintains tables used for internal processing. 
                       When Oracle Database needs to make a change to these tables, it internally generates an internal SQL statement, which in turn generates a recursive call.
      db block gets  : is the number of times a CURRENT block was requested.
      consistent gets: is the number of times a consistent read was requested for a block.
      physical reads : is the total number of data blocks read from disk. This number equals the value of �physical reads direct� plus all reads into buffer cache.
      redo size      : is the total amount of redo generated in bytes.
      bytes sent via SQL*Net to client:  is the total number of bytes sent to the client from the foreground processes.
      bytes received via SQL*Net from client: is the total number of bytes received from the client over Oracle Net.
      SQL*Net roundtrips to/from client: is the total number of Oracle Net messages sent to and received from the client.
      sorts (memory) : is the number of sort operations that were performed completely in memory and did not require any disk writes.
      sorts (disk)   : is the number of sort operations that required at least one disk write.
      rows processed : is the number of rows processed during the operation. 

      Note: The statistics printed by AUTOTRACE are retrieved from V$SESSTAT.
            db block gets indicates reads of the current block from the database. 
            consistent gets are reads of blocks that must satisfy a particular 
            system change number (SCN). physical reads indicates reads of blocks 
            from disk. db block gets and consistent gets are the two statistics 
            that are usually monitored. These should be low compared to the number 
            of rows retrieved. Sorts should be performed in memory rather than on disk.
*/

