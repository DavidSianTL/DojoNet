/* Formatted on 25/4/2024 10:23:28 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- Automatic Workload Repository (AWR)

/*
   The database automatically generates snapshots of the performance data once every 
   hour and collects the statistics in the workload repository. The data in the snapshot 
   interval is then analyzed by ADDM. The ADDM compares the differences between snapshots 
   to determine which SQL statements to capture based on the effect on the system load. 
   This reduces the number of SQL statements that need to be captured over time.
   
   Note: By using PL/SQL packages, such as DBMS_WORKLOAD_REPOSITORY or Oracle Enterprise Manager, 
   you can mange the frequency and retention period of SQL that is stored in the AWR.

*/

-- Debe tener el rol DBA
-- Creating Snapshots

EXEC DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT ('ALL');

-- Dropping Snapshots

EXEC DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE - (low_snap_id => 22, high_snap_id => 32, dbid => 3310949047);

-- Modifying Snapshot Settings (minutos)

/*
   The retention period is specified as 43,200 minutes (30 days)
   
   Interval between each snapshot is specified as 30 minutes
   
   If NULL is specified, the existing value is preserved
   
   Database identifier is 3310949047. If you do not specify a value for dbid, the local 
   database identifier is used as the default value
*/

SELECT * FROM DBA_HIST_WR_CONTROL;

EXEC DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS( -retention => 43200, interval => 30, dbid => 3310949047);

SELECT * FROM V$ACTIVE_SESSION_HISTORY;

/*
    DBA_HIST_ACTIVE_SESS_HISTORY displays the history of the contents of the sampled 
                         in-memory active session history for recent system activity. 
    DBA_HIST_BASELINE displays information about the baselines captured in the system.
    DBA_HIST_DATABASE_INSTANCE displays information about the database environment. 
    DBA_HIST_SNAPSHOT displays information about snapshots in the system. 
    DBA_HIST_SQL_PLAN displays SQL execution plans. 
    DBA_HIST_WR_CONTROL displays the settings for controlling AWR.
*/

SELECT /* revision_awr */ *
  FROM hr.employees NATURAL JOIN hr.departments;

SELECT sql_id, sql_text
  FROM v$SQL
 WHERE sql_text LIKE '%revision_awr%';

SELECT SQL_ID, SQL_TEXT
  FROM dba_hist_sqltext
 WHERE SQL_ID = ' 9qa0upvk1ahu1';

EXEC dbms_workload_repository.create_snapshot;

SELECT tf.*
  FROM DBA_HIST_SQLTEXT  ht,
       TABLE (DBMS_XPLAN.DISPLAY_AWR (ht.sql_id,
                                      NULL,
                                      NULL,
                                      'ALL')) tf
 WHERE ht.sql_text LIKE '%revision_awr%';

SELECT plan_table_output
  FROM TABLE (DBMS_XPLAN.DISPLAY_AWR ('9qa0upvk1ahu1'));
  
SELECT *
  FROM TABLE (DBMS_XPLAN.DISPLAY_AWR ('9qa0upvk1ahu1'));
  
-- @$ORACLE_HOME/rdbms/admin/awrsqrpt  
-- @$ORACLE_HOME/rdbms/admin/awrrpt