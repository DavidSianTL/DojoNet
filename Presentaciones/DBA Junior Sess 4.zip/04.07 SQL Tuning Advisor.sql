/* Formatted on 26/4/2024 16:53:01 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- SQL Tuning Advisor

SELECT /* TOTO */
       e.last_name, d.department_name
  FROM hr.employees e, hr.departments d
 WHERE e.department_id = d.department_id;

SELECT sql_id, child_number, sql_text
  FROM v$sql
 WHERE sql_text LIKE '%TOTO%';


DECLARE
    l_sql_id             VARCHAR2 (32000);
    l_sql_tune_task_id   VARCHAR2 (32000);
BEGIN
    l_sql_id := 'd130yygbf0z52';
    l_sql_tune_task_id :=
        DBMS_SQLTUNE.create_tuning_task (
            sql_id        => l_sql_id,
            scope         => DBMS_SQLTUNE.scope_comprehensive,
            time_limit    => 60,
            task_name     => 'prueba_tunning_1',
            description   => 'Tuneo de Prueba');
    --
    DBMS_OUTPUT.put_line ('l_sql_tune_task_id: ' || l_sql_tune_task_id);
END;


-- OUTPUT = l_sql_tune_task_id: prueba_tunning_1

SELECT *
  FROM DBA_ADVISOR_LOG
 WHERE task_name = 'prueba_tunning_1';

SELECT task_name, status
  FROM dba_advisor_log
 WHERE task_name LIKE 'prueba_tunning_1';

BEGIN
    DBMS_SQLTUNE.execute_tuning_task (task_name => 'prueba_tunning_1');
END;

SELECT DBMS_SQLTUNE.report_tuning_task ('prueba_tunning_1')    AS recommendations
  FROM DUAL;

-- Despu�s de aplicar la recomendaci�n se debe borrar la tarea de tunning:

EXECUTE dbms_sqltune.drop_tuning_task('prueba_tunning_1');