/* Formatted on 26/4/2024 14:38:36 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- Optimizer Statistics

-- Verificar las estad�sticas FIXED

SELECT COUNT (*)
  FROM DBA_TAB_STATISTICS
 WHERE OBJECT_TYPE = 'FIXED TABLE';

SELECT COUNT (1)
  FROM DBA_TAB_STATISTICS
 WHERE OBJECT_TYPE = 'FIXED TABLE' AND last_analyzed IS NULL;


-- PARA EL DICCIONARIO
EXEC DBMS_STATS.GATHER_FIXED_OBJECTS_STATS;
EXEC DBMS_STATS.GATHER_DICTIONARY_STATS;
EXEC dbms_stats.gather_database_stats; --> Todas las tablas

BEGIN
    DBMS_STATS.GATHER_FIXED_OBJECTS_STATS;
END;

  SELECT TABLE_NAME, LAST_ANALYZED
    FROM DBA_TAB_STATISTICS
   WHERE OWNER = 'SYS' AND TABLE_NAME LIKE 'X$%'
ORDER BY LAST_ANALYZED ASC;

-- Para todas las tablas del Owner
EXEC DBMS_STATS.GATHER_SCHEMA_STATS(ownname=>'OT',estimate_percent=>dbms_stats.auto_sample_size,granularity=>'DEFAULT',cascade=>TRUE);

-- Para una tabla especifica

EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname=>'OT',tabname=>'EMP',estimate_percent=>dbms_stats.auto_sample_size,granularity=>'DEFAULT',cascade=>TRUE);

-- Para un indice especifica

EXEC DBMS_STATS.GATHER_INDEX_STATS('ownname','indname');


-- Para una tabla particion especifica

EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname=>'BCG_B2000_PART',tabname=>'CG_AUXILIAR',partname=>'CGAUXSEP10',estimate_percent=>dbms_stats.auto_sample_size,granularity=>'DEFAULT',cascade=>TRUE);

  SELECT    'exec DBMS_STATS.GATHER_TABLE_STATS(ownname=>'''
         || owner
         || ''',tabname=>'''
         || segment_name
         || ''',partname=>'''
         || partition_name
         || ''',estimate_percent=>dbms_stats.auto_sample_size,granularity=>'''
         || 'DEFAULT'
         || ''',cascade=>TRUE);'
    FROM dba_segments
   WHERE     segment_type = 'TABLE PARTITION'
         AND tablespace_name = 'CDR_DATA_2013B'
         AND partition_name LIKE '%10'
ORDER BY segment_name, partition_name;

DECLARE
    OWNNAME            VARCHAR2 (200);
    TABNAME            VARCHAR2 (200);
    PARTNAME           VARCHAR2 (200);
    ESTIMATE_PERCENT   NUMBER;
    BLOCK_SAMPLE       BOOLEAN;
    METHOD_OPT         VARCHAR2 (200);
    DEGREE             NUMBER;
    GRANULARITY        VARCHAR2 (200);
    CASCADE            BOOLEAN;
    STATTAB            VARCHAR2 (200);
    STATID             VARCHAR2 (200);
    STATOWN            VARCHAR2 (200);
    NO_INVALIDATE      BOOLEAN;
BEGIN
    OWNNAME := 'BCG_B2000_PART';
    TABNAME := 'CG_MOVIMIENTO_DETALLE';
    PARTNAME := 'CGMDAGO10';
    ESTIMATE_PERCENT := 20;
    BLOCK_SAMPLE := TRUE;
    METHOD_OPT := 'FOR ALL INDEXED COLUMNS';
    DEGREE := NULL;
    GRANULARITY := 'PARTITION';                   -- ALL todas las particiones
    CASCADE := TRUE;
    STATTAB := NULL;
    STATID := NULL;
    STATOWN := NULL;
    NO_INVALIDATE := NULL;
    DBMS_STATS.GATHER_TABLE_STATS (OWNNAME,
                                   TABNAME,
                                   PARTNAME,
                                   ESTIMATE_PERCENT,
                                   BLOCK_SAMPLE,
                                   METHOD_OPT,
                                   DEGREE,
                                   GRANULARITY,
                                   CASCADE,
                                   STATTAB,
                                   STATID,
                                   STATOWN,
                                   NO_INVALIDATE);
    COMMIT;
END;


-- Eliminar las estadisticas de la tabla:

EXEC DBMS_STATS.delete_table_stats('TC', 'TC_CARTERA');


-- Desenllavar estad�sticas

EXEC DBMS_STATS.UNLOCK_TABLE_STATS('OWNER', 'TABLE_NAME');

-- Verificar el estatus

SELECT owner, table_name, stattype_locked
  FROM dba_tab_statistics
 WHERE stattype_locked IS NOT NULL;


SELECT    'exec DBMS_STATS.UNLOCK_TABLE_STATS('''
       || owner
       || ''','''
       || table_name
       || ''');'
  FROM dba_tab_statistics
 WHERE stattype_locked IS NOT NULL AND owner = 'BANPRO';


-- Estadisticas en Paralelo

BEGIN
    --
    DBMS_STATS.gather_table_stats (
        ownname            => 'CC',
        tabname            => 'CC_SALDOS_DIARIOS',
        partname           => 'P_2018_01',
        estimate_percent   => DBMS_STATS.auto_sample_size,
        granularity        => 'DEFAULT',
        degree             => DBMS_STATS.AUTO_DEGREE,
        cascade            => TRUE);
--
END;

/*
###################  Cost-Based Optimizer (CBO) ###################
*/
-- https://oracle-base.com/articles/misc/cost-based-optimizer-and-database-statistics

EXEC DBMS_STATS.gather_system_stats;

-- Manually start and stop to sample a representative time (several hours) of system activity.

EXEC DBMS_STATS.gather_system_stats('start');

EXEC DBMS_STATS.gather_system_stats('stop');

-- Sample from now until a specific number of minutes.

EXEC DBMS_STATS.gather_system_stats('interval', INTERVAL => 180);


SELECT pname, pval1
  FROM sys.aux_stats$
 WHERE sname = 'SYSSTATS_MAIN';

EXEC DBMS_STATS.delete_fixed_objects_stats;
EXEC DBMS_STATS.delete_system_stats;

/*
###################  Locking Stats ###################
*/
-- To prevent statistics being overwritten, you can lock the stats at schema, table or partition level.

EXEC DBMS_STATS.lock_schema_stats('OT');

EXEC DBMS_STATS.lock_table_stats('OT', 'EMP');

EXEC DBMS_STATS.lock_partition_stats('OT', 'EMP', 'EMP_PART1');

-- If you need to replace the stats, they must be unlocked.

EXEC DBMS_STATS.unlock_schema_stats('OT');

EXEC DBMS_STATS.unlock_table_stats('OT', 'EMP');

EXEC DBMS_STATS.unlock_partition_stats('OT', 'EMP', 'EMP_PART1');

/*
  Locking stats can be very useful to prevent automated jobs from changing them. This is especially useful with tables used for ETL processes. 
  If the stats are gathered when the tables are empty, they will not reflect the real quantity of data during the load process. 
  Instead, either gather stats each time the data is loaded, or gather them once on a full table and lock them.
*/