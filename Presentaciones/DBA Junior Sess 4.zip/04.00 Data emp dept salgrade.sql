/* Formatted on 25/4/2024 14:44:39 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- EMP, DEPT, SALGRADE 

/*
   To draw plan as a tree, do the following:
     1.- Take the ID with the lowest number and place it at the top.
     2.- Look for rows which have a PID (parent) equal to this value.
     3.- Place these in the tree below the Parent according to their POS values 
         from the lowest to the highest, ordered from left to right.
     4.- After all the IDs for a parent have been found, move down to the next ID 
         and repeat the process, finding new rows with the same PID.
         
   The first thing to determine in an explain plan is which node is executed first. 
   The method in the slide explains this, but sometimes with complicated plans it is 
   difficult to do this and also difficult to follow the steps through to the end. 
   Large plans are exactly the same as smaller ones, but with more entries. 
   The same basic rules apply. You can always collapse the plan to hide a branch of 
   the tree which does not consume much of the resources.
   
   Standard explain plan interpretation:
     1.- Start at the top.
     2.- Move down the row sources until you get to one which produces data, but 
         does not consume any. This is the start row source.
     3.- Look at the siblings of this row source. These row sources are executed next.
     4.- After the children are executed, the parent is executed next.
     5.- Now that this parent and its children are completed, work back up the tree, 
         and look at the siblings of the parent row source and its parents. Execute as before.
     6.- Move back up the plan until all row sources are exhausted.
   
   Standard tree interpretation:
     1.- Start at the top.
     2.- Move down the tree to the left until you reach the left node. This is executed first.
     3.- Look at the siblings of this row source. These row sources are executed next.
     4.- After the children are executed, the parent is executed next.
     5.- Now that this parent and its children are completed, work back up the tree, 
         and look at the siblings of the parent row source and its parents. Execute as before.
     6.- Move back up the tree until all row sources are exhausted.
   
   If you remember the few basic rules of explain plans and with some experience, you can read most plans easily.
*/

CREATE TABLE dept
(
    deptno    NUMBER (2, 0),
    dname     VARCHAR2 (14),
    loc       VARCHAR2 (13),
    CONSTRAINT pk_dept PRIMARY KEY (deptno)
);

CREATE TABLE emp
(
    empno       NUMBER (4, 0),
    ename       VARCHAR2 (10),
    job         VARCHAR2 (9),
    mgr         NUMBER (4, 0),
    hiredate    DATE,
    sal         NUMBER (7, 2),
    comm        NUMBER (7, 2),
    deptno      NUMBER (2, 0),
    CONSTRAINT pk_emp PRIMARY KEY (empno),
    CONSTRAINT fk_deptno FOREIGN KEY (deptno) REFERENCES dept (deptno)
);

CREATE TABLE SALGRADE
(
    GRADE    NUMBER,
    LOSAL    NUMBER,
    HISAL    NUMBER
);

INSERT INTO DEPT (DEPTNO, DNAME, LOC)
     VALUES (10, 'ACCOUNTING', 'NEW YORK');

INSERT INTO dept
     VALUES (20, 'RESEARCH', 'DALLAS');

INSERT INTO dept
     VALUES (30, 'SALES', 'CHICAGO');

INSERT INTO dept
     VALUES (40, 'OPERATIONS', 'BOSTON');

INSERT INTO emp
     VALUES (7839,
             'KING',
             'PRESIDENT',
             NULL,
             TO_DATE ('17-11-1981', 'dd-mm-yyyy'),
             5000,
             NULL,
             10);

INSERT INTO emp
     VALUES (7698,
             'BLAKE',
             'MANAGER',
             7839,
             TO_DATE ('1-5-1981', 'dd-mm-yyyy'),
             2850,
             NULL,
             30);

INSERT INTO emp
     VALUES (7782,
             'CLARK',
             'MANAGER',
             7839,
             TO_DATE ('9-6-1981', 'dd-mm-yyyy'),
             2450,
             NULL,
             10);

INSERT INTO emp
     VALUES (7566,
             'JONES',
             'MANAGER',
             7839,
             TO_DATE ('2-4-1981', 'dd-mm-yyyy'),
             2975,
             NULL,
             20);

INSERT INTO emp
     VALUES (7788,
             'SCOTT',
             'ANALYST',
             7566,
             TO_DATE ('13-JUL-87', 'dd-mm-rr') - 85,
             3000,
             NULL,
             20);

INSERT INTO emp
     VALUES (7902,
             'FORD',
             'ANALYST',
             7566,
             TO_DATE ('3-12-1981', 'dd-mm-yyyy'),
             3000,
             NULL,
             20);

INSERT INTO emp
     VALUES (7369,
             'SMITH',
             'CLERK',
             7902,
             TO_DATE ('17-12-1980', 'dd-mm-yyyy'),
             800,
             NULL,
             20);

INSERT INTO emp
     VALUES (7499,
             'ALLEN',
             'SALESMAN',
             7698,
             TO_DATE ('20-2-1981', 'dd-mm-yyyy'),
             1600,
             300,
             30);

INSERT INTO emp
     VALUES (7521,
             'WARD',
             'SALESMAN',
             7698,
             TO_DATE ('22-2-1981', 'dd-mm-yyyy'),
             1250,
             500,
             30);

INSERT INTO emp
     VALUES (7654,
             'MARTIN',
             'SALESMAN',
             7698,
             TO_DATE ('28-9-1981', 'dd-mm-yyyy'),
             1250,
             1400,
             30);

INSERT INTO emp
     VALUES (7844,
             'TURNER',
             'SALESMAN',
             7698,
             TO_DATE ('8-9-1981', 'dd-mm-yyyy'),
             1500,
             0,
             30);

INSERT INTO emp
     VALUES (7876,
             'ADAMS',
             'CLERK',
             7788,
             TO_DATE ('13-JUL-87', 'dd-mm-rr') - 51,
             1100,
             NULL,
             20);

INSERT INTO emp
     VALUES (7900,
             'JAMES',
             'CLERK',
             7698,
             TO_DATE ('3-12-1981', 'dd-mm-yyyy'),
             950,
             NULL,
             30);

INSERT INTO emp
     VALUES (7934,
             'MILLER',
             'CLERK',
             7782,
             TO_DATE ('23-1-1982', 'dd-mm-yyyy'),
             1300,
             NULL,
             10);

INSERT INTO SALGRADE
     VALUES (1, 700, 1200);

INSERT INTO SALGRADE
     VALUES (2, 1201, 1400);

INSERT INTO SALGRADE
     VALUES (3, 1401, 2000);

INSERT INTO SALGRADE
     VALUES (4, 2001, 3000);

INSERT INTO SALGRADE
     VALUES (5, 3001, 9999);

COMMIT;