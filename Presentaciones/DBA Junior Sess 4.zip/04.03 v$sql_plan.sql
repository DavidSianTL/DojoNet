/* Formatted on 25/4/2024 09:27:50 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- V$SQL_PLAN, V$SQL_PLAN_STATISTICS, V$SQL_PLAN_STATISTICS_ALL  

SELECT e.last_name, d.department_name
  FROM hr.employees e, hr.departments d
 WHERE e.department_id = d.department_id;

SELECT SQL_ID, SQL_TEXT
  FROM V$SQL
 WHERE SQL_TEXT LIKE '%SELECT e.last_name,%';

SELECT plan_table_output
  FROM TABLE (DBMS_XPLAN.DISPLAY_cursor ('guyrg2vdjhybs'));
  
/*
  The FORMAT parameter controls the level of detail for the plan. In addition to the 
  standard values (BASIC, TYPICAL, SERIAL, ALL, and ANDVANCED), there are additional 
  supported values to display run-time statistics for the cursor: 
     IOSTATS: Assuming that the basic plan statistics are collected when SQL statements 
              are executed (either by using the GATHER_PLAN_STATISTICS hint or by setting 
              the statistics_level parameter to ALL), this format shows I/O statistics for 
              ALL (or only for LAST) executions of the cursor.
     MEMSTATS: Assuming that the Program Global Area (PGA) memory management is enabled 
              (that is, the pga_aggregate_target parameter is set to a nonzero value), 
              this format allows to display memory management statistics (for example, 
              execution mode of the operator, how much memory was used, number of bytes 
              spilled to disk, and so on). These statistics only apply to memory-intensive 
              operations, such as hash joins, sort or some bitmap operators.
     ALLSTATS: A shortcut for 'IOSTATS MEMSTATS'
     LAST: By default, plan statistics are shown for all executions of the cursor. The LAST 
              keyword can be specified to see only the statistics for the last execution.
*/  