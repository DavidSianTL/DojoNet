/* Formatted on 25/4/2024 15:49:54 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- Interpreting an Execution Plan 

/*
   To draw plan as a tree, do the following:
     1.- Take the ID with the lowest number and place it at the top.
     2.- Look for rows which have a PID (parent) equal to this value.
     3.- Place these in the tree below the Parent according to their POS values 
         from the lowest to the highest, ordered from left to right.
     4.- After all the IDs for a parent have been found, move down to the next ID 
         and repeat the process, finding new rows with the same PID.
         
   The first thing to determine in an explain plan is which node is executed first. 
   The method in the slide explains this, but sometimes with complicated plans it is 
   difficult to do this and also difficult to follow the steps through to the end. 
   Large plans are exactly the same as smaller ones, but with more entries. 
   The same basic rules apply. You can always collapse the plan to hide a branch of 
   the tree which does not consume much of the resources.
   
   Standard explain plan interpretation:
     1.- Start at the top.
     2.- Move down the row sources until you get to one which produces data, but 
         does not consume any. This is the start row source.
     3.- Look at the siblings of this row source. These row sources are executed next.
     4.- After the children are executed, the parent is executed next.
     5.- Now that this parent and its children are completed, work back up the tree, 
         and look at the siblings of the parent row source and its parents. Execute as before.
     6.- Move back up the plan until all row sources are exhausted.
   
   Standard tree interpretation:
     1.- Start at the top.
     2.- Move down the tree to the left until you reach the left node. This is executed first.
     3.- Look at the siblings of this row source. These row sources are executed next.
     4.- After the children are executed, the parent is executed next.
     5.- Now that this parent and its children are completed, work back up the tree, 
         and look at the siblings of the parent row source and its parents. Execute as before.
     6.- Move back up the tree until all row sources are exhausted.
   
   If you remember the few basic rules of explain plans and with some experience, you can read most plans easily.
*/

SELECT /*+ RULE */
       ENAME,
       job,
       sal,
       dname
  FROM emp, dept
 WHERE     dept.deptno = emp.deptno
       AND NOT EXISTS
               (SELECT *
                  FROM salgrade
                 WHERE emp.sal BETWEEN losal AND hisal);

EXPLAIN PLAN
    FOR SELECT /*+ RULE */
               ENAME,
               job,
               sal,
               dname
          FROM emp, dept
         WHERE     dept.deptno = emp.deptno
               AND NOT EXISTS
                       (SELECT *
                          FROM salgrade
                         WHERE emp.sal BETWEEN losal AND hisal);

SELECT * FROM DBMS_XPLAN.DISPLAY ();

Plan hash value: 243245009

--------------------------------------------------
| Id  | Operation                     | Name     |
--------------------------------------------------
|   0 | SELECT STATEMENT              |          |
|*  1 |  FILTER                       |          |
|   2 |   NESTED LOOPS                |          |
|   3 |    NESTED LOOPS               |          |
|   4 |     TABLE ACCESS FULL         | EMP      |
|*  5 |     INDEX UNIQUE SCAN         | PK_DEPT  |
|   6 |    TABLE ACCESS BY INDEX ROWID| DEPT     |
|*  7 |   TABLE ACCESS FULL           | SALGRADE |
--------------------------------------------------

/*
   The execution order is 3-5-4-2-6-1:

   3: The plan starts with a full table scan of EMP (ID=3).
   5: The rows are passed back to the controlling nested loops join step (ID=2), 
      which uses them to execute the lookup of rows in the PK_DEPT index in ID=5.
   4: The ROWIDs from the index are used to lookup the other information from the 
      DEPT table in ID=4.
   2: ID=2, the nested loops join step, is executed until completion.
   6: After ID=2 has exhausted its row sources, a full table scan of SALGRADE in 
      ID=6 (at the same level in the tree as ID=2, therefore, its sibling) is executed.
   1: This is used to filter the rows from ID2 and ID6.
   
*/

ALTER SESSION SET STATISTICS_LEVEL =  ALL;

SELECT /*+ RULE  para asegurarse que reproduce el  100%*/
       ENAME,
       job,
       sal,
       dname
  FROM emp, dept
 WHERE     dept.deptno = emp.deptno
       AND NOT EXISTS
               (SELECT *
                  FROM salgrade
                 WHERE emp.sal BETWEEN losal AND hisal);

SELECT *
  FROM TABLE (DBMS_XPLAN.DISPLAY_CURSOR (NULL, NULL, 'TYPICAL IOSTATS LAST'));
  
Plan hash value: 243245009

----------------------------------------------------------------------------------------------------
| Id  | Operation                     | Name     | Starts | A-Rows |   A-Time   | Buffers | Reads  |
----------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT              |          |      1 |      0 |00:00:00.01 |      85 |     14 |
|*  1 |  FILTER                       |          |      1 |      0 |00:00:00.01 |      85 |     14 |
|   2 |   NESTED LOOPS                |          |      1 |     14 |00:00:00.01 |      25 |      8 |
|   3 |    NESTED LOOPS               |          |      1 |     14 |00:00:00.01 |      11 |      7 |
|   4 |     TABLE ACCESS FULL         | EMP      |      1 |     14 |00:00:00.01 |       7 |      6 |
|*  5 |     INDEX UNIQUE SCAN         | PK_DEPT  |     14 |     14 |00:00:00.01 |       4 |      1 |
|   6 |    TABLE ACCESS BY INDEX ROWID| DEPT     |     14 |     14 |00:00:00.01 |      14 |      1 |
|*  7 |   TABLE ACCESS FULL           | SALGRADE |     12 |     12 |00:00:00.01 |      60 |      6 |
----------------------------------------------------------------------------------------------------  

/*
   A-Rows corresponds to the number of rows produced by the corresponding row source.
   Buffers corresponds to the number of consistent reads done by the row source.
   Starts indicates how many times the corresponding operation was processed.
   
   For each row from the EMP table, the system gets its ENAME, SAL, JOB, and DEPTNO.
   Then the system accesses the DEPT table by its unique index (PK_DEPT) to get DNAME 
     using DEPTNO from the previous result set.
   If you observe the statistics closely, the TABLE ACCESS FULL operation on the EMP 
     table (ID=3) is started once. However, operations from ID 5 and 4 are started 
     14 times; once for each EMP rows. At this step (ID=2), the system gets all 
     ENAME, SAL, JOB, and DNAME. 
   The system now must filter out employees who have salaries outside the range 
     of salaries in the salary grade table. To do that, for each row from ID=2, 
     the system accesses the SALGRADE table using a FULL TABLE SCAN operation to 
     check if the employee�s salary is outside the salary range. This operation 
     only needs to be done 12 times in this case because at run time the system 
     does the check for each distinct salary, and there are 12 distinct salaries 
     in the EMP table.
     
*/

SELECT /*+ USE_NL(d) use_nl(m) */
       m.last_name AS dept_namager, d.department_name, l.street_address
  FROM hr.employees  m
       JOIN hr.departments d ON (d.manager_id = m.employee_id)
       NATURAL JOIN hr.locations l
 WHERE l.city = 'Seattle';
 
SELECT * FROM DBMS_XPLAN.DISPLAY (); 

Plan hash value: 243245009

--------------------------------------------------
| Id  | Operation                     | Name     |
--------------------------------------------------
|   0 | SELECT STATEMENT              |          |
|*  1 |  FILTER                       |          |
|   2 |   NESTED LOOPS                |          |
|   3 |    NESTED LOOPS               |          |
|   4 |     TABLE ACCESS FULL         | EMP      |
|*  5 |     INDEX UNIQUE SCAN         | PK_DEPT  |
|   6 |    TABLE ACCESS BY INDEX ROWID| DEPT     |
|*  7 |   TABLE ACCESS FULL           | SALGRADE |
--------------------------------------------------

/*
   1.- Start at the top. ID=0 
   2.- Move down the row sources until you get to the one, which produces data, 
       but does not consume any. In this case, ID 0, 1, 2, and 3 consume data. 
       ID=4 is the first row source that does not consume any. This is the start 
       row source. ID=4 is executed first. The index range scan produces ROWIDs, 
       which are used to lookup in the LOCATIONS table in ID=3.
   3.- Look at the siblings of this row source. These row sources are executed next. 
       The sibling at the same level as ID=3 is ID=5. Node ID=5 has a child ID=6, 
       which is executed before it. This is another index range scan producing ROWIDs, 
       which are used to lookup in the DEPARTMENTS table in ID=5.
   4.- After the children operation, the parent operation is next. The NESTED LOOPS 
       join at ID=2 is executed next bringing together the underlying data.
   5.- Now that this parent and its children are completed, walk back up the tree, 
       and look at the siblings of the parent row source and its parents. Execute as 
       before. The sibling of ID=2 at the same level in the plan is ID=7. This has a 
       child ID=8, which is executed first. The index unique scan produces ROWIDs, which 
       are used to lookup in the EMPLOYEES table in ID=7.
   6.- Move back up the plan until all row sources are exhausted. Finally this is brought 
       together with the NESTED LOOPS at ID=1, which passes the results back to ID=0.
   7.- The execution order is: 4 � 3 � 6 � 5 � 2 � 8 � 7 � 1 � 0

   Here is the complete description of this plan:
   The inner nested loops is executed first using LOCATIONS as the driving table, 
     using an index access on the CITY column. This is because you search for departments 
     in Seattle only.
   The result is joined with the DEPARTMENTS table, using the index on the LOCATION_ID 
     join column; the result of this first join operation is the driving row source for 
     the second nested loops join.
   The second join probes the index on the EMPLOYEE_ID column of the EMPLOYEES table. 
     The system can do that because it knows (from the first join) the employee ID of all 
     managers of departments in Seattle. Note that this is a unique scan because it is 
     based on the primary key.
   Finally, the EMPLOYEES table is accessed to retrieve the last name.

*/

SELECT /*+ ORDERED USER_HASH(b) SWAP_JOIN_INPUTS(c) */
       MAX (a.i)
  FROM t1 a, t2 b, t3 c
 WHERE a.i = b.i AND a.i = c.i;
 
/*
   Here is the interpretation of this plan:
     The system first hashes the T3 table (Operation ID=3) into memory.
     Then it hashes the T1 table (Operation ID=5) into memory.
     Then the scan of the T2 table begins (Operation ID=6).
     The system picks a row from T2 and probes T1 (T1.i=T2.i).
     If the row survives, the system probes T3 (T1.i=T3.i).
     If the row survives, the system sends it to next operation.
     The system outputs the maximum value from the previous result set.
   
   In conclusion, the execution order is : 3 � 5 � 6 � 4 � 2 � 1
   The join order is: T1 � T2 � T3
   You can also use Enterprise Manager to understand execution plans, especially 
     because it displays the Order column.
   Note: A special hint was used to make sure T3 would be first in the plan.

*/ 

/*******************************************************************************

   Reviewing the Execution Plan:
   
   When you tune a SQL statement in an online transaction processing (OLTP) environment, 
   the goal is to drive from the table that has the most selective filter. This means 
   that there are fewer rows passed to the next step. If the next step is a join, this 
   means fewer rows are joined. Check to see whether the access paths are optimal. When 
   you examine the optimizer execution plan, look for the following:
   - The plan is such that the driving table has the best filter.
   - The join order in each step means that the fewest number of rows are returned 
      to the next step (that is, the join order should reflect going to the best not-yet-used filters).
   - The join method is appropriate for the number of rows being returned. For example, 
     nested loop joins through indexes may not be optimal when many rows are returned.
   - Views are used efficiently. Look at the SELECT list to see whether access to the view is necessary.
   - There are any unintentional Cartesian products (even with small tables).
   - Each table is being accessed efficiently: Consider the predicates in the SQL statement and the 
     number of rows in the table. Look for suspicious activity, such as a full table scans on tables 
     with large number of rows, which have predicates in the WHERE clause. Also, a full table scan 
     might be more efficient on a small table, or to leverage a better join method (for example, 
     hash_join) for the number of rows returned.
   
   If any of these conditions are not optimal, consider restructuring the SQL statement or the indexes available on the tables.

*******************************************************************************/