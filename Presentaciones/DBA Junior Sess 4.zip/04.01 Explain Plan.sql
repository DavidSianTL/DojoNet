/* Formatted on 24/4/2024 14:23:26 (QP5 v5.396) */
/*
SELECT * FROM NLS_SESSION_PARAMETERS;

ALTER SESSION SET NLS_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_TERRITORY= 'AMERICA';
ALTER SESSION SET NLS_CURRENCY= '$';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS= '.,';
ALTER SESSION SET NLS_DATE_LANGUAGE= 'AMERICAN';
ALTER SESSION SET NLS_DUAL_CURRENCY= '$';
*/

/*******************************************************************************
  Tuning
*******************************************************************************/

-- EXPLAIN PLAN: No es ejecutado, presenta teoricamente el plan de ejecuci�n

EXPLAIN PLAN SET STATEMENT_ID = 'demo01'
    FOR SELECT e.last_name, d.department_name
          FROM hr.employees e, hr.departments d
         WHERE e.department_id = d.department_id;

EXPLAIN PLAN SET STATEMENT_ID = 'demo01'
    FOR SELECT *
          FROM emp
         WHERE ename = 'KING';

-- PLAN_TABLE: Explain inserta en la tabla PLAN_TABLE

SELECT * FROM plan_table;

/*
   Crear una tabla permanente usando $ORACLE_HOME/rdbms/admin/utlxplan.sql 
   Se recomienda recrearla luego de un upgrade de la BD por cambios en la misma.
*/

SET LINESIZE 130
SET PAGESIZE 0

SELECT * FROM TABLE (DBMS_XPLAN.DISPLAY ());

SELECT *
  FROM TABLE (DBMS_XPLAN.DISPLAY ('plan_table',          -- Nombre de la tabla
                                  'demo01',
                                  'typical',      -- Informacion mas relevante
                                  NULL));

SELECT * FROM TABLE (DBMS_XPLAN.DISPLAY (NULL, NULL, 'ALL'));

 /*
   IOSTATS, MEMSTATS, ALLSTATS and LAST.
   �-PROJECTION�   --> Exclude
   
   ROWS: If relevant, shows the number of rows estimated by the optimizer
   BYTES: If relevant, shows the number of bytes estimated by the optimizer
   COST: If relevant, shows optimizer cost information
   PARTITION: If relevant, shows partition pruning information
   PARALLEL: If relevant, shows PX information (distribution method and table queue information)
   PREDICATE: If relevant, shows the predicate section
   PROJECTION: If relevant, shows the projection section
   ALIAS: If relevant, shows the �Query Block Name/Object Alias� section 
   REMOTE: If relevant, shows the information for the distributed query (for example, remote from serial distribution and remote SQL)
   NOTE: If relevant, shows the note section of the explain plan 
 */

SELECT *
  FROM TABLE (
           DBMS_XPLAN.DISPLAY (NULL,
                               NULL,
                               'ADVANCED PROJECTION PREDICATE ALIAS'));

SELECT last_name
  FROM hr.employees e, hr.departments d
 WHERE e.department_id = d.department_id AND e.employee_id = 149;

-- Se necesita permiso de SELECT en V$SESSION

SELECT * FROM DBMS_XPLAN.DISPLAY_CURSOR ();

SELECT /* TOTO */
       e.last_name, d.department_name
  FROM hr.employees e, hr.departments d
 WHERE e.department_id = d.department_id;
 
SELECT sql_id, child_number
  FROM v$sql
 WHERE sql_text LIKE '%TOTO%';

SELECT * FROM DBMS_XPLAN.DISPLAY_CURSOR ('crup2zs7rb0hj', 0);

ALTER TABLE hr.employees
    PARALLEL;

EXPLAIN PLAN
    FOR SELECT e.last_name, d.department_name
          FROM hr.employees e, hr.departments d
         WHERE e.department_id = d.department_id;

SET LINESIZE 130
SET PAGESIZE 0

SELECT * FROM DBMS_XPLAN.DISPLAY();
         