﻿namespace Trabajo_APIRest.Dtos.UsuarioDtos
{
    public class UsuarioResponseDto
    {
        public string Token { get; set; }
        public string Usuario { get; set; }

    }
}
