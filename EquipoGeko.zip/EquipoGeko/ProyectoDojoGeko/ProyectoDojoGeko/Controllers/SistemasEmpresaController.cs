﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoDojoGeko.Controllers
{
    public class SistemasEmpresaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
