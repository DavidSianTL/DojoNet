﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoDojoGeko.Controllers
{
    public class BitacorasController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
