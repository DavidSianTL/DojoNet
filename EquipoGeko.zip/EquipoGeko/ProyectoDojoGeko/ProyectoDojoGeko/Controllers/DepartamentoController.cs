﻿using Microsoft.AspNetCore.Mvc;
using ProyectoDojoGeko.Data;
using ProyectoDojoGeko.Filters;

namespace ProyectoDojoGeko.Controllers
{
    [AuthorizeSession]
    public class DepartamentoController : Controller
    {
        private readonly daoDepartamentoWSAsync _daoDepartamento;

        public DepartamentoController()
        {
            string _connectionString = "Server=db20907.public.databaseasp.net;Database=db20907;User Id=db20907;Password=A=n95C!b#3aZ;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True;";
            _daoDepartamento = new daoDepartamentoWSAsync(_connectionString);
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [AuthorizeRole("SuperAdmin", "Admin")]
        [HttpGet]
        public IActionResult AgregarDepartamento()
        {
            return View("Agregar", "Departamento");
        }

        [AuthorizeRole("SuperAdmin")]
        [HttpGet]
        public IActionResult EditarDepartamento()
        {
            return View("Editar", "Departamento");
        }

        [HttpPost]
        public IActionResult EliminarDepartamento(int Id)
        {
            // Lógica para eliminar departamento
            return RedirectToAction("Index");
        }
    }
}


