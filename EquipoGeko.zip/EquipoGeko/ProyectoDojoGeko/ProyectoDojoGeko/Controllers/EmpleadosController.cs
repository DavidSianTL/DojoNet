﻿using Microsoft.AspNetCore.Mvc;
using ProyectoDojoGeko.Models;
using ProyectoDojoGeko.Data;
using ProyectoDojoGeko.Filters;

namespace ProyectoDojoGeko.Controllers
{
    [AuthorizeSession]
    public class EmpleadosController : Controller
    {
        private readonly daoEmpleadoWSAsync _daoEmpleado;
        private readonly daoUsuarioWSAsync _daoUsuario;
        private readonly daoRolesWSAsync _daoRoles;
        private readonly daoSistemaWSAsync _daoSistema;
        private readonly daoLogWSAsync _daoLog;
        private readonly daoBitacoraWSAsync _daoBitacora;

        public EmpleadosController()
        {
            string connectionString = "Server=db20907.public.databaseasp.net;Database=db20907;User Id=db20907;Password=A=n95C!b#3aZ;Encrypt=True;TrustServerCertificate=True;MultipleActiveResultSets=True;";

            _daoEmpleado = new daoEmpleadoWSAsync(connectionString);
            _daoUsuario = new daoUsuarioWSAsync(connectionString);
            _daoRoles = new daoRolesWSAsync(connectionString);
            _daoSistema = new daoSistemaWSAsync(connectionString);
            _daoLog = new daoLogWSAsync(connectionString);
            _daoBitacora = new daoBitacoraWSAsync(connectionString);
        }

        private async Task RegistrarError(string accion, Exception ex)
        {
            var usuario = HttpContext.Session.GetString("Usuario") ?? "Sistema";
            await _daoLog.InsertarLogAsync(new LogViewModel
            {
                Accion = $"Error {accion}",
                Descripcion = $"Error al {accion} por {usuario}: {ex.Message}",
                Estado = false
            });
        }

        private async Task RegistrarBitacora(string accion, string descripcion)
        {
            var idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            var usuario = HttpContext.Session.GetString("Usuario") ?? "Sistema";
            var idSistema = HttpContext.Session.GetInt32("IdSistema") ?? 0;

            await _daoBitacora.InsertarBitacoraAsync(new BitacoraViewModel
            {
                Accion = accion,
                Descripcion = $"{descripcion} | Usuario: {usuario}",
                FK_IdUsuario = idUsuario,
                FK_IdSistema = idSistema
            });
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            try
            {
                var empleados = await _daoEmpleado.ObtenerEmpleadoAsync();
                await RegistrarBitacora("Vista Empleados", "Acceso a lista de empleados");
                return View(empleados ?? new List<EmpleadoViewModel>());
            }
            catch (Exception ex)
            {
                await RegistrarError("acceder a vista de empleados", ex);
                return View(new List<EmpleadoViewModel>());
            }
        }

        [HttpGet]
        public async Task<IActionResult> LISTAR(int id)
        {
            try
            {
                var empleado = await _daoEmpleado.ObtenerEmpleadoPorIdAsync(id);
                if (empleado == null)
                {
                    await RegistrarError("listar empleado", new Exception($"Empleado {id} no encontrado"));
                    return NotFound();
                }
                await RegistrarBitacora("Listar Empleado", $"ID: {id}");
                return View(empleado);
            }
            catch (Exception ex)
            {
                await RegistrarError("listar empleado", ex);
                return RedirectToAction("Index");
            }
        }

        [HttpGet]
        public async Task<IActionResult> Detalle(int id)
        {
            try
            {
                var empleado = await _daoEmpleado.ObtenerEmpleadoPorIdAsync(id);
                if (empleado == null)
                {
                    await RegistrarError("ver detalle empleado", new Exception($"Empleado {id} no encontrado"));
                    return NotFound();
                }
                await RegistrarBitacora("Detalle Empleado", $"ID: {id}");
                return View(empleado);
            }
            catch (Exception ex)
            {
                await RegistrarError("ver detalle empleado", ex);
                return RedirectToAction("Index");
            }
        }

        [HttpGet]
        public IActionResult CREAR()
        {
            return View(new EmpleadoViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CREAR(EmpleadoViewModel empleado)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _daoEmpleado.InsertarEmpleadoAsync(empleado);
                    await RegistrarBitacora("Crear Empleado", $"Nuevo empleado creado");
                    return RedirectToAction("Index");
                }
                return View(empleado);
            }
            catch (Exception ex)
            {
                await RegistrarError("crear empleado", ex);
                return View(empleado);
            }
        }

        [HttpGet]
        public async Task<IActionResult> EDITAR(int id)
        {
            try
            {
                var empleado = await _daoEmpleado.ObtenerEmpleadoPorIdAsync(id);
                if (empleado == null)
                {
                    await RegistrarError("editar empleado", new Exception($"Empleado {id} no encontrado"));
                    return NotFound();
                }
                await RegistrarBitacora("Editar Empleado", $"ID: {id}");
                return View(empleado);
            }
            catch (Exception ex)
            {
                await RegistrarError("editar empleado", ex);
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public async Task<IActionResult> EDITAR(EmpleadoViewModel empleado)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _daoEmpleado.ActualizarEmpleadoAsync(empleado);
                    await RegistrarBitacora("Actualizar Empleado", $"ID: {empleado.IdEmpleado}");
                    return RedirectToAction("Index");
                }
                return View(empleado);
            }
            catch (Exception ex)
            {
                await RegistrarError("actualizar empleado", ex);
                return View(empleado);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ELIMINAR(int id)
        {
            try
            {
                var empleado = await _daoEmpleado.ObtenerEmpleadoPorIdAsync(id);
                if (empleado == null)
                {
                    await RegistrarError("eliminar empleado", new Exception($"Empleado {id} no encontrado"));
                    return NotFound();
                }
                await RegistrarBitacora("Eliminar Empleado", $"ID: {id}");
                return View(empleado);
            }
            catch (Exception ex)
            {
                await RegistrarError("eliminar empleado", ex);
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ELIMINAR(int id, IFormCollection collection)
        {
            try
            {
                await _daoEmpleado.EliminarEmpleadoAsync(id);
                await RegistrarBitacora("Empleado Eliminado", $"ID: {id}");
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                await RegistrarError("eliminar empleado", ex);
                return RedirectToAction("ELIMINAR", new { id });
            }
        }
    }
}