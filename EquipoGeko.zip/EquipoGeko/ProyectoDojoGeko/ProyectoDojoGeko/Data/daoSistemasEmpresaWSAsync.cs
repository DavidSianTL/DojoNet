﻿namespace ProyectoDojoGeko.Data
{
    public class daoSistemasEmpresaWSAsync
    {
    }
}
