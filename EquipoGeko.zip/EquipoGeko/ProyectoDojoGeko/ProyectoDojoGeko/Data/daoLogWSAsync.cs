﻿namespace ProyectoDojoGeko.Data
{
    public class daoLogWSAsync
    {
    }
}
