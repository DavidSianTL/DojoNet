﻿namespace ProyectoDojoGeko.Models.SistemasEmpresa
{
    
    public class VistaSistemasEmpresaViewModel
    {

        public int IdSistemasEmpresa { get; set; }

        public int IdEmpresa { get; set; }

        public string NombreEmpresa { get; set; } = string.Empty;

        public int IdSistema { get; set; }

        public string NombreSistema { get; set; } = string.Empty;


    }
}
