﻿namespace ProyectoDojoGeko.Models
{
    public class SistemasEmpresaViewModel
    {
    }
}
